<script type="javascript">
  funtion fun1()
   if(n1.hit=="")
   {
    alert("enter the appropreate userid ")
   }
   if(n1.sit=="")
   {
    alert("enter the valid password" )

   }



</script>