DELIMITER //
CREATE trigger emp.salary 
AFTER UPDATE on emp FOR EACH ROW
BEGIN 
INSERT INTO emp_track values(old.salary,new.salary);
END//
DELIMITER //