#include<stdio.h>
#include<string>
 int main()
 {
    
 }