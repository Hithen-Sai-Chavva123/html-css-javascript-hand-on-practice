#include<stdio.h>
#include<string.h>
 int main()
 {
    int a[20],b[20],i,j,k,count,n;
    printf("enter teh siz4e of frame size:");
    scanf("%d",&n);
    printf("enter the frame in the form 0 and 1:");
    for(i=0;i<n;i++)
    {
      scanf("%d",&a[i]);

    }
    i=0;
    count=1;
    j=0;
    while (i<n)
    {
      if(a[i]==1)
      {
         b[j]=a[j];
         for(k=i+1, a[k]==1;  k<n && count<5;k++)
         {
            j++;
            b[j]=a[k];
            count++;
         }
         if(count==5)
         {
            j++;
            b[j]=0;
         }
         i=k;
      }
      else{
         b[j]=a[k];
         j++;
         i++;
      }
     
    }
    printf("after bit stuffing");
      for(i=0;i<j;i++)
      {
         printf("%d",b[i]);
         return 0;
      }
    
 }